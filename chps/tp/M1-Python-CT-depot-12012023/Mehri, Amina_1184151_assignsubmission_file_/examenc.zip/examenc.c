#include <stdio.h>
#include <stdlib.h>
#include<string.h>

int main()
{
float **ini_gris;
int i,j,k,n;

 printf("Choisir la taille  de la gris A:\n");
{  scanf("%d",&n);
    }
        

while(n<=8)
{for(int i=0,i>n;i++){ 
for int j=0,j>n;j++){
    if ((i+j)%2==0)
    ini_gris[i][j]="v";
    else:
    ini_gris[i][j]="m";
}
}
ini_gris[n][n]="f";
 //x=(float *)malloc(n*sizeof(float));
 ini_gris=(char **)malloc(n*sizeof(char *));

 for (j=0;j<n;j++)
 {
   ini_gris[j]=(char *)malloc(n*sizeof(char));
 }


  printf("Afficher les elements de la gris A:\n");
     for(int i=0;i<n;i++)
        {for(int j=0;j<n;j++)
         {  printf("%char",ini_gris[i][j]);
        }
        }
}
return 0;
}