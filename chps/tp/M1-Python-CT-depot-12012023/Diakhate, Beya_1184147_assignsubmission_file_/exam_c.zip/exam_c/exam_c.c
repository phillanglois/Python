# include<stdio.h>
# include<stdlib.h>
// fonction initialisation matrice
float **intialisation(int n){
    int i,j;
    float **u;
    u = (double**)malloc(n*sizeof(double*));
  for(i=0;i<n;i++) {
    u[i] = (double*)malloc(n*sizeof(double));
  }
    for(i=0;i<n;i++){
        for(j=0;j<n;j++){
            u[i][j]=rand();
            }
}
return u;
}
//fonction écriture du fichier
void ecrire_matrix(double **a, int m, int n, char *f) {
    FILE *fp=NULL;
    fp=fopen(f,"w");
    fprintf(fp,"%d \n", m);
    fprintf(fp,"%d \n", n);
    int i,j;
    for(i=0;i<n;i++){
        for(j=0;j<m;j++){
               fprintf(fp,"%lf ", a[i][j]);
            }
        fprintf(fp,"\n");
    }
    fclose(fp);
}
// fonction lecture fichier
void lire_matrix(double **a, int m, int n, char *f) {
    FILE *fp=NULL;
    fp=fopen(f,"r");
    fscanf(fp,"%d \n", &m);
    fscanf(fp,"%d \n", &n);
    int i,j;
    for(i=0;i<n;i++){
        for(j=0;j<m;j++){
               fscanf(fp,"%lf ", &a[i][j]);
            }
        fscanf(fp,"\n");
    }
    fclose(fp);
}
// affichage


int main (){
    int m;
    float *initialisation;
    printf("donner la taille");
    scanf("% d",&m);
    initialisation(m);
}